package com.loan.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanmanagementApplication.class, args);
	}

}
